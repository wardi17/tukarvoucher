// index.js

// import { getTampilData } from './initCalendar.js';
// import { getkategori } from './kategori.js';




$(document).ready(function () {
     //etTampilData();

 const root = ReactDOM.createRoot(document.getElementById('root'));
console.log(root);
// root.render(<Ms_Inventari/>)
  
});

