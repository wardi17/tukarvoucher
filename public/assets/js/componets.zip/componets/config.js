export const baseUrl = window.BASE_URL;
